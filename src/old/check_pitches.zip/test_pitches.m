clc
clear
close all

[C3, FS]  = audioread('semitone_scale/130.8.wav');
Db3 = audioread('semitone_scale/138.6.wav');
D3  = audioread('semitone_scale/146.8.wav');
Eb3 = audioread('semitone_scale/155.6.wav');
E3  = audioread('semitone_scale/164.8.wav');
F3  = audioread('semitone_scale/174.6.wav');
Gb3 = audioread('semitone_scale/185.0.wav');
G3  = audioread('semitone_scale/196.0.wav');
Ab3 = audioread('semitone_scale/207.7.wav');
A3  = audioread('semitone_scale/220.0.wav');
Bb3 = audioread('semitone_scale/233.1.wav');
B3  = audioread('semitone_scale/246.9.wav');
C4  = audioread('semitone_scale/261.6.wav');

%easy access to the n'th scale degree
scale = {C3, Db3, D3, Eb3, E3, F3, Gb3, G3, Ab3, A3, Bb3, B3, C4};
truth = [130.8 138.6 146.8 155.6 164.8 174.6 185.0 196.0 207.7 220.0 233.1 246.9 261.6]; 

%play a chord (Cmaj add 2 add 7)
% play_chord({C3, D3, E3, G3, B3}, FS);

for i = 1:length(scale)
    p = BSAC_pitch(scale{i}(1:20000), FS); %only use the first 10000 samples
    t = truth(i);
    error = abs((t-p)/t);
    fprintf('Prediction: %.02f, Actual: %.02f, Error: %.02f\n', p, t, error*100);
%     if error > 0.05
%         soundsc(scale{i}(1:130000), FS);
%     end
end