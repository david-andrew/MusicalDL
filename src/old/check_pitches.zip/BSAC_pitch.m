function [pitch] = BSAC_pitch(sound, FS)
% BSAC_pitch (BitStreamAutoCorrelation) returns the pitch of a given sound
%   The algorithm is detailed here: https://www.cycfi.com/2018/03/fast-and-efficient-pitch-detection-bitstream-autocorrelation/
%   right now it's not very pretty. maybe add schmidt trigger behavior?

%convert the sound into bits (booleans)
sound = sound >= 0;

%strip off bits until a zero-crossing is on both sides
start = 1; stop = length(sound) - 1;
while sound(1) == sound(start)
    start = start + 1;
end
while sound(end) == sound(stop)
    stop = stop - 1;
end
sound = sound(start:stop); %strip off any waveform before first zero cross and after last zero cross


%set up a reasonable window (based on human voice range)
min_frequency = 16.0; %Hz (C0). In general humans don't sing this low
min_length = floor(FS / min_frequency); %minimum period length for our lowest note 
window_size = min_length * 4;

%take sample from start and get vector lengths
sample = sound(1:window_size);
sample_length = length(sample);
test_length = length(sound)-length(sample)+1; %how many correlations are tested


%allocate array to hold results of the autocorrelations 
correlations = zeros(test_length, 1,  'double'); 

for i1 = 1:test_length
    correlations(i1) = sum(xor(sample, sound(i1:i1+sample_length-1))) / window_size; %normalize
end


mu = mean(correlations);
sigma = std(correlations);
mins_x = zeros(floor(test_length / min_length), 1); %preallocate array to hold minimums we find
mins_y = zeros(floor(test_length / min_length), 1);
n = 1; %number of minimums found
best_min = inf;

%find minimums
for i1 = 1:test_length-1
    if correlations(i1) < mu-sigma %looking for mins
        if correlations(i1) < best_min
            best_min = correlations(i1);
        end
        
        %check if we are about to cross line of 1-std below mean
        if correlations(i1+1) >= mu-sigma
            %store the minimums we found in a list
            mins_x(n) = i1;
            mins_y(n) = best_min;
            %update the number of minimums and reset the best_min value
            n = n + 1;
            best_min = inf;
        end            
    end 
end


%compute pitch based on similar spacings of minimums
%take the lowest value several after the first one
skip = 5;
check = 20; %at 44100Hz this is about 0.1 seconds long? depends on the pitch

%only check a small subset
my = mins_y(skip:skip+check);
mx = mins_x(skip:skip+check);

%filter out only the minimums. also we only care about the indexies at this point
mu = mean(my);
sigma = std(my)*0.1;
mx = mx(my < mu - sigma); 
my = my(my < mu - sigma);


%plot minimums vs those selected
figure
hold on
plot(correlations(1:mins_x(end)));
plot(mins_x, mins_y);
plot(mx, my, 'ok');

%compute period by looking at the average differenc between each index
period_length = mode(diff(mx));

pitch = FS / period_length;

end

